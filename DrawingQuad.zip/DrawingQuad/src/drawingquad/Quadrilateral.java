/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package drawingquad;

import java.awt.Graphics;

/**
 *
 * @author Hani
 */
public class Quadrilateral 
{
    
    
    public void draw(Graphics g)
    {
        // use g.drawLine(x1, y1, x2, y2)
    }
}